import React, { useState } from 'react'

function contact() {
  return (
    <div>
        <nav>
        <li><a href="#Home">Home</a></li>
        <li><a href="#Contact">Contact</a></li>
        <li><a href="#Produits">Produits</a></li>
        <li><a href="#Adresse">Adresse</a></li>
      </nav>
      <footer><h1>copyright 2024</h1></footer>
    </div>
  )
}

export default contact
